#!/bin/bash
. ./func.sh

result2=$(factorial 4)
echo "result2=$result2"
