#!/bin/bash
rnd=$RANDOM
echo "$rnd"
