#!/bin/bash
xte 'key space'
