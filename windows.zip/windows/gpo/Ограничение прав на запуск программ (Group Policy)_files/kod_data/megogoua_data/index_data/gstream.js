/**
 * @author Gemius / gemiusStream
 * @date 2017-04-10
*/

function gemius_pending(i) { window[i] = window[i] || function() {var x = window[i+'_pdata'] = window[i+'_pdata'] || []; x[x.length]=arguments;};};
gemius_pending('gemius_hit'); gemius_pending('gemius_event'); gemius_pending('pp_gemius_hit'); gemius_pending('pp_gemius_event');

if (typeof gemiusStream2 == 'undefined' || typeof gemiusStream2.streams == 'undefined') {
	gemiusStream2 = {
		streams : {},
		instanceid : ((new Date()).getTime()),
		interval : 20*60,
		init : function() {
			setInterval(gemiusStream2.timer,gemiusStream2.interval * 1000);
			try {
				gemiusStream2.add_event(window.top, 'unload', gemiusStream2.unload);
			} catch (e) {
				gemiusStream2.add_event(window, 'unload', gemiusStream2.unload);
			}
		},
		newStream : function(playerid, contentid, duration, custom_package, additional_package, identifier/*, hitcollector, treeIds*/) {
			if (!identifier) return;
			var custom_params = gemiusStream2.format_package(custom_package);
			var add_params = gemiusStream2.format_package(additional_package);
			var extra = ["_SPI="+gemiusStream2.instanceid, "_SP="+playerid, "_SC="+contentid, "_SCD="+duration].concat(custom_params).concat(add_params);
			gemiusStream2.set_stream(playerid, contentid, identifier, extra);
			gemiusStream2.send_hit(playerid, contentid, "newStream", []);
		},
		event : function(playerid, contentid, time, event_type) {
			var evtypes = {"playing":"play", "paused":"pause", "stopped":"stop", "buffering":"buffering", "seekingStarted":"seek", "complete":"complete"};
			if (gemiusStream2.streams[playerid] && gemiusStream2.streams[playerid][contentid] && evtypes[event_type]) {
				var params = ["_SCO="+time, "_SED="+gemiusStream2.get_elapsed_duration(playerid, contentid)];
				event_type = evtypes[event_type];
				gemiusStream2.streams[playerid][contentid]["state"] = event_type;
				gemiusStream2.streams[playerid][contentid]['last_action_time'] = (new Date()).getTime();
				if (event_type == "play" && gemiusStream2.streams[playerid][contentid]["played"] == false) {
					gemiusStream2.streams[playerid][contentid]["played"] = true;
					gemiusStream2.send_hit(playerid, contentid, "start", params);
				} else {
					gemiusStream2.send_hit(playerid, contentid, event_type, params);
				}
			}
		},
		closeStream : function(playerid, contentid, time) {
			if (gemiusStream2.streams[playerid] && gemiusStream2.streams[playerid][contentid]) {
				var params = ["_SCO="+time, "_SED="+gemiusStream2.get_elapsed_duration(playerid, contentid)];
				gemiusStream2.send_hit(playerid, contentid, "close", params);
				delete gemiusStream2.streams[playerid][contentid];
			}
		},
		/* private functions */
		set_stream : function(playerid, contentid, identifier, params) {
			if (typeof gemiusStream2.streams[playerid] == 'undefined') {
				gemiusStream2.streams[playerid] = {};
			}
			gemiusStream2.streams[playerid][contentid] = {"state": "newStream", "played": false, "last_action_time": null, "identifier": identifier, "params": params};
		},
		get_elapsed_duration : function(playerid, contentid) {
			var stream = gemiusStream2.streams[playerid][contentid];
			var duration = 0;
			try {
				if (stream['state'] == 'play' && stream['last_action_time']) {
					duration =  Math.round(((new Date()).getTime() - stream['last_action_time']) / 1000);
					if (duration < 0 || duration > 2*gemiusStream2.interval) {
						duration = 0;
					}
				}
			} catch (e) {}
			return duration;
		},
		add_event : function(obj,type,fn) {
			if (obj.addEventListener) {
				obj.addEventListener(type, fn, false);
			} else if (obj.attachEvent) {
				obj.attachEvent('on'+type, fn);
			}
		},
		timer : function() {
			for (var playerid in gemiusStream2.streams) {
				for (var contentid in gemiusStream2.streams[playerid]) {
					if (gemiusStream2.streams[playerid][contentid]["state"] == "play") {
						var params = ["_SED="+gemiusStream2.get_elapsed_duration(playerid, contentid)];
						gemiusStream2.streams[playerid][contentid]['last_action_time'] = (new Date()).getTime();
						gemiusStream2.send_hit(playerid, contentid, "continue", params);
					}
				}
			}
		},
		unload : function(event) {
			try {
				var delay = false;
				for (var playerid in gemiusStream2.streams) {
					for (var contentid in gemiusStream2.streams[playerid]) {
						if (gemiusStream2.streams[playerid][contentid]["state"] == "play") {
							var params = ["_SED="+gemiusStream2.get_elapsed_duration(playerid, contentid)];
							gemiusStream2.send_hit(playerid, contentid, "unload", params);
							delete gemiusStream2.streams[playerid][contentid];
							delay = true;
						}
					}
				}
				if (delay) {
					var start = (new Date()).getTime();
					while (start+250>(new Date()).getTime());
				}
			} catch(e) {}
		},
		send_hit : function(playerid, contentid, event_type, args) {
			if (gemiusStream2.streams[playerid] && gemiusStream2.streams[playerid][contentid]) {
				var stream = gemiusStream2.streams[playerid][contentid];
				var params = ["_EC="+event_type].concat(args).concat(stream['params']);
				gemius_event.apply(this, ['_stream_', stream.identifier].concat(params));
			}
		},
		format_package : function(arr) {
			var res = [];
			if (!arr || !arr.length) {
				return [];
			}
			for (var i=0; i<arr.length; i++) {
				switch (typeof arr[i]) {
					case ("string"):
						res[res.length] = arr[i];
						break;
					case ("object"):
						if (arr[i].length) {
							if (arr[i].length == 2) {
								res[res.length] = arr[i][0] + "=" + arr[i][1];
							}
						}
						else {
							if (typeof arr[i]["name"] != "undefined") {
								res[res.length] = arr[i]["name"] + "=" + arr[i]["value"];
							}
						}
						break;
				}			
			}
			return res;
		}
	}
	gemiusStream2.init();
}


function gsm_gemius_escape(str,limit) {
	function Hex(n) {
		var hexMap = "0123456789ABCDEF";
		return hexMap.charAt(n>>4)+hexMap.charAt(n&0xF);
	}
	var c,s,uc,ul;
	var dst = "";
	for (var i=0 ; i<str.length ; i++) {
		c = str.charCodeAt(i);
		if ((c>=0xDC00)&&(c<0xE000)) continue;
		if ((c>=0xD800)&&(c<0xDC00)) {
			i++;
			if (i>=str.length) continue;
			s = str.charCodeAt(i);
			if ((s<0xDC00)||(s>=0xE000)) continue;
			c = ((c-0xD800)<<10)+(s-0xDC00)+0x10000;
		}
		if (c<0x80) {
			uc = escape(String.fromCharCode(c)).replace(/\+/g,"%2B").replace(/\//g,"%2F");
			if (c<=0x20) {
				ul=3;
			} else {
				ul=1;
			}
		} else if (c<0x800) {
			uc = "%"+Hex((c>>6)|0xC0)+"%"+Hex((c&0x3F)|0x80);
			ul = 2;
		} else if (c<0x10000) {
			uc = "%"+Hex((c>>12)|0xE0)+"%"+Hex(((c>>6)&0x3F)|0x80)+"%"+Hex((c&0x3F)|0x80);
			ul = 3;
		} else if (c<0x200000) {
			uc = "%"+Hex((c>>18)|0xF0)+"%"+Hex(((c>>12)&0x3F)|0x80)+"%"+Hex(((c>>6)&0x3F)|0x80)+"%"+Hex((c&0x3F)|0x80);
			ul = 4;
		} else {
			uc = "";
			ul = 0;
		} 
		limit -= ul;
		if (limit<0) {
			return dst;
		}
		dst+=uc;
	}
	return dst;
}

if(!gSmDebug){
	var gSmDebug = new function(){

		this.DEBUGLEVEL_CONNECTOR = "connector";
		this.DEBUGLEVEL_LOG = "log";
		this.DEBUGLEVEL_INPUT = "input";
		this.DEBUGLEVEL_INTERNAL = "internal";
		this.DEBUGLEVEL_OUTPUT = "output";
		this.ACTIONNAME_NEW_STREAM = "newStream";
		this.ACTIONNAME_EVENT = "event";
		this.ACTIONNAME_CLOSE_STREAM = "closeStream";
		this.ACTIONNAME_SEND_HIT = "sendHit";
		this.ACTIONNAME_LOG = "log";

		this._connectionId = "_" + ((new Date()).getTime().toString(36)) + "_" + (Math.floor(Math.random() * 99999).toString(36));
		this._isEliminated = false;
		this._isRegistered = false;
		this._registerInterval = Math.floor(2000 + (Math.random() * 1000));
		this._actionsBuffer = new Array();

		this.init = function(){
			setTimeout("gSmDebug._sendRegisterRequest()", this._registerInterval);
		}

		this.receiveConfirmation = function(){
			this.send(this.DEBUGLEVEL_CONNECTOR, "", "", this.ACTIONNAME_LOG, ["<PLAYER>[" + this._connectionId + "]" + " >> Confirmation received."]);
			this._isRegistered = true;
			setTimeout("gSmDebug._releaseEventsBuffer()", 1);
		}

		this.send = function(debugLevel, playerId, contentId, actionName, actionData) {
			if (!this._isEliminated) {
				var action = new Object();
				action["debugLevel"] = debugLevel;
				action["connectionId"] = this._connectionId;
				action["timestamp"] = new Date().getTime();
				action["playerId"] = playerId;
				action["contentId"] = contentId;
				action["actionName"] = actionName;
				action["actionData"] = actionData;
				if (this._isRegistered) {
					this._sendActionToDebugger(action);
				} else {
					this._actionsBuffer.push(action);
				}
			}
		}

		this._sendRegisterRequest = function(){
			if (!gSmDebug._isRegistered) {
				gSmDebug.send(gSmDebug.DEBUGLEVEL_CONNECTOR, "", "", gSmDebug.ACTIONNAME_LOG, ["<PLAYER>[" + gSmDebug._connectionId + "]" + " >> Send to <DEBUGGER>.register(" + gSmDebug._connectionId + ")."]);
				if(gSmDebug._getDebugger()) {
					gSmDebug._getDebugger().register(gSmDebug._connectionId);
				}

				gSmDebug._registerInterval += Math.floor(1000 + (Math.random() * 500));
				if(gSmDebug._registerInterval < 60000) {
					setTimeout("gSmDebug._sendRegisterRequest()", gSmDebug._registerInterval);
				}
			}
		}

		this._releaseEventsBuffer = function() {
			for (var i = 0; i < gSmDebug._actionsBuffer.length; i++) {
				gSmDebug._sendActionToDebugger(gSmDebug._actionsBuffer[i]);
			}
			gSmDebug._actionsBuffer = new Array();
		}

		this._sendActionToDebugger = function(action) {
			if (this._getDebugger()) {
				this._getDebugger().receiveAction(action["debugLevel"], action["connectionId"], action["timestamp"], action["playerId"], action["contentId"], action["actionName"], action["actionData"]);
			}
		}

		this._getDebugger = function() {
			return document.getElementById("gSmDebugger");
		}

		this.init();

	}
}

if(!gSmUtil){
	var gSmUtil = new function(){

		this._protectedInterval = 100;
		this._oldSystemTime = (new Date()).getTime();
		this._oldSystemTimeTmp = (new Date()).getTime();
		this._newSystemTime = (new Date()).getTime();
		this._currentTime = 0;
		this._delta = 0;

		this.init = function(){
			setTimeout("gSmUtil._updateProtectedTime()", this._protectedInterval);
		}

		this.getTimeSec = function(){
			return this._currentTime;
		}

		this.isOpera = function(){
			return (window.opera);
		}

		this.isSafari = function(){
			if(this.isChrome()) return false;
			return (navigator.userAgent.toLowerCase().indexOf('safari') != -1);
		}

		this.isChrome = function(){
			return (navigator.userAgent.toLowerCase().indexOf('chrome') != -1);
		}

		this.isIE = function(){
			return (navigator.appName.toLowerCase().indexOf("microsoft") != -1);
		}

		this.isFF = function(){
			return (navigator.userAgent.toLowerCase().indexOf("firefox") != -1);
		}

		this.getBytesLength = function(str) {
			return encodeURIComponent(str).replace(/%../g, 'x').length;
		}

		this.limitBytesLength = function(str, maxBytes, restricted) {
			var currBytes = 0;
			var outStr = "";
			str = this._normalizeString(str, restricted);
			for (var i = 0 ; i < str.length ; i++ ) {
				currBytes += this.getBytesLength(str.charAt(i));
				if (currBytes > maxBytes) return outStr;
				outStr += str.charAt(i);
			}
			return outStr;
		}

		this.sendHit = function(hitcollector, identifier, encoding, data) {
			identifier += '&sargencoding=' + encoding;
			identifier += '&sarg=' + gsm_gemius_escape(data,1023);
			gemius_hit.apply(window, [identifier]);
		}

		this._updateProtectedTime = function(){
			setTimeout("gSmUtil._updateProtectedTime()", gSmUtil._protectedInterval);
			gSmUtil._newSystemTime = (new Date()).getTime();
			var diff = gSmUtil._newSystemTime - gSmUtil._oldSystemTimeTmp - gSmUtil._protectedInterval;
			if(diff < -1000 || diff > 60000){
				gSmUtil._delta -= diff;
			}
			gSmUtil._oldSystemTimeTmp = gSmUtil._newSystemTime;
			gSmUtil._currentTime = Math.floor((gSmUtil._newSystemTime - gSmUtil._oldSystemTime + gSmUtil._delta)/1000);
		}

		this._normalizeString = function(str,restricted) {
			var result = "";
			for (var i=0; i < str.length; i++) {
				var ok = true;
				for (var j=0; j < restricted.length; j++) {
					if (str.charAt(i) == restricted[j]) {
						ok = false;
						break;
					}
				}
				result += (ok) ? str.charAt(i) : " ";
			}
			return result;
		}

		this.init();

	}
}

if(!gSmStorageUnload){
	var gSmStorageUnload = new function(){
		this.STREAM_HISTORY_LIFE_TIME = 259200000;
		this.STREAM_HISTORY_BUFFOR_TIME = 2000;
		this.UPDATESTREAM_INTERVAL = 500;
		this.INSTANCE_PREFIX = "gsm_Hiedu6me_";

		this.init = function(){
			if (!this.isStorageUnload())
				return;
			this.instanceId = this.INSTANCE_PREFIX + (new Date()).getTime() + "" + Math.round(Math.random() * 1000);
			this._sendStorages();
			setTimeout(function() { gSmStorageUnload._updateStorage();}, this.UPDATESTREAM_INTERVAL);
		}

		this.isStorageUnload = function(){
			try {
				if (!gSmUtil.isOpera() && !gSmUtil.isChrome() && !gSmUtil.isSafari())
					return false;
				if (typeof localStorage == 'undefined')
					return false;
				if (localStorage == null)
					return false;
				if (!JSON)
					return false;
				if (typeof JSON.parse !== 'function')
					return false;
				return true;
			} catch (e) {
				return false;
			}
		}

		this._updateStorage = function() {
			var storage = {
				"lastUpdate": (new Date()).getTime(),
				"streams": []
			}
			for (var i = 0; i < gemiusStream.playersArray.length; i++) {
				var player = gemiusStream.playersArray[i];
				for ( var j = 0; j < player._streamsArray.length; j++ ) {
					var stream = player._streamsArray[j];
					if (!stream.isPlaying)
						continue;
					storage.streams.push({
						'identifier': stream.gSmId,
						'encoding': gSmConfig.ENCODING,
						'startTime': stream.startTime,
						'sarg': stream.getCurrentPackage()
					});
				}
			}
			try {
				if ( storage.streams.length == 0 ) {
					localStorage.removeItem(this.instanceId);
				} else {
					localStorage.setItem(this.instanceId, JSON.stringify(storage));
				}
			} catch(e) {}
			setTimeout(function() { gSmStorageUnload._updateStorage();}, this.UPDATESTREAM_INTERVAL);
		}

		this._sendStorages = function(){
			var ls_keys = []
			try {
				for (var i = 0; i < localStorage.length; i++){
					if (localStorage.key(i).search(this.INSTANCE_PREFIX) != 0)
						continue;
					if (localStorage.key(i) == this.instanceId)
						continue;
					ls_keys.push(localStorage.key(i));
				}
			} catch (e) {
			}
			for (var i = 0; i < ls_keys.length; i++ ) {
				this._sendStorage(ls_keys[i]);
			}

		}

		this._sendStorage = function(key) {
				try {
					storage = JSON.parse(localStorage.getItem(key));
					storage_life_time = (new Date()).getTime() - storage.lastUpdate;
					if (storage_life_time < this.STREAM_HISTORY_BUFFOR_TIME)
						return;
					if (storage_life_time < this.STREAM_HISTORY_LIFE_TIME) {
						for (var j = 0; j < storage.streams.length; j++) {
							var stream = storage.streams[j];
							var sarg_parts = stream.sarg.split("|");
							var event_parts = sarg_parts[sarg_parts.length-1].split(";");
							if (event_parts[event_parts.length - 1][0] == 0){
								sarg_parts.splice(sarg_parts.length - 1, 1);
							}
							if (sarg_parts.length >= 8){
								var stream_life_time = ((new Date()).getTime() - stream.startTime)/1000;
								sarg_parts[6] = Math.round(Math.max(Number(sarg_parts[6]), stream_life_time));
								var sarg = sarg_parts.join("|");
								gSmUtil.sendHit(stream.hitcollector, stream.identifier, stream.encoding, sarg);
								gSmDebug.send(gSmDebug.DEBUGLEVEL_OUTPUT, "", "", gSmDebug.ACTIONNAME_SEND_HIT, [sarg, "Cookie"]);
							}
						}
					}
				} catch(e) {}
				try {
					localStorage.removeItem(key);
				} catch(e) {}
		}

		this.init();
	}
}

var gSmStream = function(contentId, player){

	this._contentId = contentId;
	this._contentIdFormated = gSmUtil.limitBytesLength(contentId, gSmConfig.MAX_ID_LENGTH, gSmConfig.ID_RES);
	this._player = player;

	this.init = function(){
		this._closing = false;
		this.duration = null;
		this.time = null;
		this.customPackageString = "";
		this.additionalPackageString = "";
		this.lastPlayTime = null;
		this.lastEvent = "";
		this.lastPlayEndTime = null;
		this.firstTimeStamp = gSmUtil.getTimeSec();
		this.lastTimeStamp = gSmUtil.getTimeSec();
		this.isPlaying = false;
		this.forcedClose = false;
		this.controlBreak = false;
		this.eventString = "";
		this.eventId = "";
		this.viewId = "";
		this.cookieId = "";
		this.gSmId = "";
		this.gSmHost = "";
		this.treeIdString = "";
		this.realPlaying = false;
	}

	this.init();

	this.newStream = function (duration, customPackage, additionalPackage, gSmId, gSmHc, treeId){
		this.init();
		this.gSmId = (gSmId == undefined || gSmId == null) ? gsm_gemius_identifier : gSmId;
		this.duration = (duration>0) ? Math.round(duration) : -1;
		this.time = 0;
		this.customPackageString = this._formatPackage(customPackage);
		this.additionalPackageString = this._formatPackage(additionalPackage);
		this.treeIdString = this._formatTree(treeId);
		this.startTime = (new Date()).getTime();
		gSmDebug.send(gSmDebug.DEBUGLEVEL_INTERNAL, this._player.playerId, this._contentId, gSmDebug.ACTIONNAME_NEW_STREAM, [this.duration, this.customPackageString, this.additionalPackageString, this.treeIdString]);
	}

	this.event = function(time, eventType){
		this.forcedClose = false;
		this.time = time;

		if (this.lastEvent == eventType) return;

		gSmDebug.send(gSmDebug.DEBUGLEVEL_INTERNAL, this._player.playerId, this._contentId, gSmDebug.ACTIONNAME_EVENT, [Math.round(time), eventType]);
		switch(eventType){
			case "playing":
				if (this.isPlaying) return;

				if (this.eventString == "") this.firstTimeStamp = gSmUtil.getTimeSec();
				this.lastTimeStamp = gSmUtil.getTimeSec();
				this.lastPlayTime = time;
				this.eventId = "p";
				if (!this.firsPlayingEvent) this._sendFirsPlayingEvent();
				this.realPlaying = true;
				this.isPlaying = true;
				this.viewId = "";
				break;
			case "complete":
				this.eventId = "c";
				this.lastPlayEndTime = time;
				this.sendStream();
				this.isPlaying = false;
				this.viewId = "";
				this.firsPlayingEvent = false;
				break;
			default:
				switch(eventType){
					case "paused":
						this.eventId = "p";
						break;
					case "stopped":
						this.eventId = "s";
						break;
					case "buffering":
						this.eventId = "b";
						break;
					case "seekingStarted":
						this.eventId = "r";
						break;
					default:
						this.eventId = "p";
						break;
				}
				if (this.lastPlayTime == null)return;
				this.lastPlayEndTime = time;
				this.controlBreak = "length";
				var currEvent = this._getCurrEvent();
				if (!this._checkBufforAndSendHit(currEvent)) {
					this.eventString += this._makeCurrEventViewId(currEvent);
				}
				this.isPlaying = false;
				break;
		}
	}

	this.closeStream = function(time){
		this._closing = true;
		this.time = time;
		this.lastPlayEndTime = time;
		gSmDebug.send(gSmDebug.DEBUGLEVEL_INTERNAL, this._player.playerId, this._contentId, gSmDebug.ACTIONNAME_CLOSE_STREAM, [Math.round(this.time)]);
		this.sendStream();
		this.isPlaying = false;
	}

	this.getCurrentPackage = function(){
		var events = this._getEvents(true);
		var viewId = (this.viewId != "") ? ("#" + this.viewId) : ("");
		return this._getFormatedData() + "|" + Math.round(this.lastTimeStamp - this.firstTimeStamp) + ";" + Math.round(this.lastPlayTime) + ";" + Math.round(this._getPlayLength(true)) + viewId + events;
	}

	this.closeStreamForced = function(){
		this._closing = true;
		gSmDebug.send(gSmDebug.DEBUGLEVEL_INTERNAL, this._player.playerId, this._contentId, gSmDebug.ACTIONNAME_CLOSE_STREAM, [Math.round(this.time)]);
		this.forcedClose = true;
		this.sendStream();
		this.isPlaying = false;
	}

	this.sendStream = function(controlBreak){
		this.controlBreak = (controlBreak == undefined || controlBreak == null) ? "" : controlBreak;
		if (this.controlBreak == "time" && (this._getCurrEvent() + this.eventString != "")){
			if (this.viewId == "") {
				this.viewId = gemiusStream.newViewId();
			}
		}
		var playLength = this._getPlayLength();
		var currEvent = this._getCurrEvent();
		if (!this._checkBufforAndSendHit(currEvent)) {
			this.eventString += this._makeCurrEventViewId(currEvent);
			this._sendHit("");
			this.lastPlayTime += playLength;
		}
		if (this.controlBreak == "time") {
			this.realPlaying = false;
		}
	}

	this.hasEvent = function(){
		this.forcedClose = true;
		if (this.eventString + this._getCurrEvent() != "") {
			return true;
		}
		return false;
	}

	this._formatPackage = function(arr) {
		var str = "";
		var criterion;
		var category;
		var max_i = (arr.length > gSmConfig.MAX_CRITERIONS) ? gSmConfig.MAX_CRITERIONS : arr.length;
		for (var i = 0; i < max_i; i++) {
			switch (typeof(arr[i])) {
				case ("string"):
					arr[i] = arr[i].split("=");
					break;
				case ("object"): //FIX dont use objects in array. Only Strings in array
					if (!arr[i].length) arr[i] = [arr[i]["name"], arr[i]["value"]];
					break;
				default:
					arr[i] = [];
					break;
			}			
			if (arr[i].length == 2) {
				criterion = gSmUtil.limitBytesLength(arr[i][0], gSmConfig.MAX_CRITERION_LENGTH, gSmConfig.CRITERION_RES);
				category = gSmUtil.limitBytesLength(arr[i][1], gSmConfig.MAX_CATEGORY_LENGTH, gSmConfig.CATEGORY_RES);
				if (i > 0) str += ";";
				str += criterion + "=" + category;
			}
		}
		return str;
	}

	this._formatTree = function(arr) {
		var out = arr.join(",");
		while (arr.length > 0 && gSmUtil.getBytesLength(out) > gSmConfig.MAX_TREE_ID_LENGTH){
			arr.pop();
			out = arr.join(",");
		}
		return out;
	}

	this._checkBufforAndSendHit = function(currEvent) {
		if (gSmUtil.getBytesLength(this._getFormatedData()) + currEvent.length + 1 >= (gSmConfig.MAX_LOG_LENGTH + gSmConfig.VIEW_ID_LENGTH)){
			this._sendHit(currEvent);
			return true;
		}
		return false;
	}

	this._sendFirsPlayingEvent = function() {
		this._sendHit("", true);
		this.firsPlayingEvent = true;
	}

	this._makeCurrEventViewId = function(currEvent) {
		return currEvent + ((this.viewId != "" && currEvent != "") ? ("#" + this.viewId) : (""));
	}

	this._getPlayLength = function(operaCheck) {
		if (operaCheck == undefined || operaCheck == null) operaCheck = false;
		if (this.isPlaying == false) return 0;
		var tCalc, tGet, tGetR;
		tCalc = gSmUtil.getTimeSec() - this.lastTimeStamp;
		tGet = this.lastPlayEndTime - this.lastPlayTime;
		tGetR = Math.round(this.lastPlayEndTime) - Math.round(this.lastPlayTime);
		if(this.forcedClose == true || this.duration==-1 || this.controlBreak != "" || operaCheck == true){
			return tCalc;
		} else if (tGetR==1 || tGetR==0) {
			return tGetR;
		} else if (tCalc<=0) {
			return tGet;
		} else if (tGet<=0) {
			return tCalc;
		} else {
			return Math.min(tCalc, tGet);
		}
	}

	this._getEvents = function(exit){
		exit = (exit == undefined)?false:exit;
		var events = "";
		if (this.controlBreak == "" || this.controlBreak == "length" || exit) {
			events = ((this.viewId != "") ? "" : "^p") + ((this.forcedClose || exit || this._closing) ? "$q" : ("$"+this.eventId));
		} else {
			events = (this.realPlaying) ? "^p" : "";
			if (this.eventId != "p") events = "^" + this.eventId;
		}
		return events;
	}

	this._getCurrEvent = function(){
		var playLength = Math.round(this._getPlayLength());
		if (playLength > 0) {
			return "|" + Math.round(this.lastTimeStamp - this.firstTimeStamp) + ";" + Math.round(this.lastPlayTime) + ";" + playLength + this._getEvents();
		}else{
			return "";
		}
	}

	this._sendHit = function(currEvent, forced){
		if (forced == undefined) {
			forced = false;
		}
		if (this.eventString == "" && currEvent == "" && forced == false) {
			return;
		}
		this.eventString += currEvent;
		if (this.eventId == "c"){
			var parr = this.eventString.split("|");
			var estr = parr[parr.length-1];
			var st = estr.indexOf("$");
			var fstr = estr.substring(0,st) + "$c" + estr.substring(st + 2, estr.length);
			parr[parr.length-1] = fstr;
			this.eventString = parr.join("|");
		}
		var outputData = this._getFormatedData(forced);
		this.eventString = "";
		this.firstTimeStamp = gSmUtil.getTimeSec();
		this.lastTimeStamp = gSmUtil.getTimeSec();
		gSmUtil.sendHit(this.gSmHc, this.gSmId, gSmConfig.ENCODING, outputData);
		gSmDebug.send(gSmDebug.DEBUGLEVEL_OUTPUT, this._player.playerId, this._contentId, gSmDebug.ACTIONNAME_SEND_HIT, [outputData]);
	}

	this._getFormatedData = function(forced){
		var out = "";
		var delta = Math.round(gSmUtil.getTimeSec() - this.firstTimeStamp);
		var forcedData = "";
		if (forced) forcedData = "|" + Math.round(gSmUtil.getTimeSec() - this.firstTimeStamp) + ";" + Math.round(this.lastPlayTime) + ";0!f";
		out = "v=" + gSmConfig.VERSION + "|" + this.treeIdString + "|" + this._contentIdFormated + "|" + this.duration + "|" + this.customPackageString + "|" + this.additionalPackageString + "|" + delta + forcedData;
		out += this.eventString;
		return out;
	}

}

var gSmPlayer = function(playerId){

	this.playerId = playerId;
	this._streamsArray = new Array();

	this.newStream = function(contentId, duration, customPackage, additionalPackage, gSmId, gSmHost, treeId){
		var stream = this._getStream(contentId, true);
		stream.newStream(duration, customPackage, additionalPackage, gSmId, gSmHost, treeId);
	}

	this.event = function(contentId, time, eventType){
		var stream = this._getStream(contentId);
		if (stream == null) return;
		stream.event(time, eventType);
	}

	this.closeStream = function(contentId, time){
		var stream = this._getStream(contentId);
		if (stream == null) return;
		stream.closeStream(time);
		this._removeStream(contentId);
	}

	this.sendAllStreams = function(type){
		for (var i=0; i < this._streamsArray.length; i++) {
			this._streamsArray[i].sendStream(type);
		}
	}
	this.checkAllStreams = function(){
		for (var i=0; i < this._streamsArray.length; i++) {
			if (this._streamsArray[i].hasEvent()) return true;
		}
		return false;
	}
	this.closeAllStreams = function(){
		for (var i=0; i < this._streamsArray.length; i++) {
			this._streamsArray[i].closeStreamForced();
		}
	}

	this._getStream = function(contentId, forced){
		forced = (forced) ? true : false;
		var stream = null;
		for (var i=0; i < this._streamsArray.length; i++) {
			if (this._streamsArray[i]._contentId == contentId) stream = this._streamsArray[i];
		}
		if (stream == null && forced) {
			stream = new gSmStream(contentId, this);
			this._streamsArray.push(stream);
		}
		return stream;
	}

	this._removeStream = function(contentId) {
		for (var i=0; i < this._streamsArray.length; i++) {
			if (this._streamsArray[i].contentId == contentId) {
				delete this._streamsArray[i];
				this._streamsArray.splice(i, 1);
			}
		}
	}

}

if (!gSmConfig){
	var gSmConfig = new function(){

		this.VERSION = 6;
		this.MAX_CRITERIONS = 6;
		this.MAX_CRITERION_LENGTH = 16;
		this.MAX_CATEGORY_LENGTH = 64;
		this.MAX_TREE_ID_LENGTH = 64;
		this.MAX_ID_LENGTH = 64;
		this.VIEW_ID_LENGTH = 16;
		this.ID_RES = ["|", "*", "\n", "\t", "\r"];
		this.CRITERION_RES = ["|", "*", "\n", "\t", "\r", ";", "=", "/", "#"];
		this.CATEGORY_RES = ["|", "*", "\n", "\t", "\r", ";", "=", "/", "#"];
		this.TIMEOUT = 300;
		this.MAX_LOG_LENGTH = 990;
		this.ENCODING = "utf-8";

		this.setEncoding = function(encoding){
			this.ENCODING = encoding;
		}

	}
}

if (typeof gemiusStream == 'undefined' || typeof gemiusStream.checkAllStreams == 'undefined'){
	var gemiusStream = new function(){
		this._lastTimeCheck = gSmUtil.getTimeSec();
		this._viewId = 0;

		this.init = function(){
			this.session = (new Date()).getTime().toString(36) + Math.round(Math.random() * 100000000).toString(36) + Math.round(Math.random() * 100000000).toString(36);
			this.playersArray = new Array();
			if(!gSmStorageUnload.isStorageUnload()){
				if (window.addEventListener){
					window.addEventListener('unload', this.onUnload, true);
				} else if(window.attachEvent){
					window.attachEvent('onunload', this.onUnload);
				}
			}
			setTimeout("gemiusStream._timeCheck()", 1000);
			if (typeof window['gemius_stream_data'] != 'undefined') {
				var i;
				for (i=0 ; i<window['gemius_stream_data'].length ; i++) {
					gemiusStream[window['gemius_stream_data'][i][0]].apply(this,window['gemius_stream_data'][i][1]);
				}
				window['gemius_stream_data']=[];
			}
		}

		this.newStream = function(playerId, contentId, duration, customPackage, additionalPackage, gSmId, gSmHc, treeId){
			gSmDebug.send(gSmDebug.DEBUGLEVEL_INPUT, playerId, contentId, gSmDebug.ACTIONNAME_NEW_STREAM, [duration, customPackage, treeId, additionalPackage]);
			if (playerId == null || contentId == null || playerId==undefined || contentId==undefined) return;
			if (customPackage == null) customPackage = new Array();
			if (additionalPackage == null) additionalPackage = new Array();
			if (treeId == null) treeId = new Array();
			var player = this._getPlayer(playerId);
			player.newStream(contentId, duration, customPackage, additionalPackage, gSmId, gSmHc, treeId);
			gemiusStream2.newStream(playerId, contentId, duration, customPackage, additionalPackage, (typeof gemius_stream2_identifier == 'undefined')?null:gemius_stream2_identifier);
		}

		this.event = function(playerId, contentId, time, eventType){
			gSmDebug.send(gSmDebug.DEBUGLEVEL_INPUT, playerId, contentId, gSmDebug.ACTIONNAME_EVENT, [time, eventType]);
			if (playerId == null || contentId == null || playerId==undefined || contentId==undefined) return;
			var player = this._getPlayer(playerId);
			player.event(contentId, time, eventType);
			gemiusStream2.event(playerId, contentId, time, eventType);
		}

		this.closeStream = function(playerId, contentId, time){
			gSmDebug.send(gSmDebug.DEBUGLEVEL_INPUT, playerId, contentId, gSmDebug.ACTIONNAME_CLOSE_STREAM, [time]);
			if (playerId == null || contentId == null || playerId==undefined || contentId==undefined) return;
			var player = this._getPlayer(playerId);
			player.closeStream(contentId, time);
			gemiusStream2.closeStream(playerId, contentId, time);
		}

		this.checkAllStreams = function(){
			for (var i=0; i < this.playersArray.length; i++) {
				if (this.playersArray[i].checkAllStreams()) return true;
			}
			return false;
		}

		this.closeAllStreams = function(){
			for (var i=0; i < this.playersArray.length; i++) {
				this.playersArray[i].closeAllStreams();
			}
		}

		this.onUnload = function(){
			if (!gemiusStream.checkAllStreams()) return;
			gemiusStream.closeAllStreams();
			var start = (new Date()).getTime();
			while (start + 200 > (new Date()).getTime()); //pause to send hit (200ms)
		}

		this.viewId = function(){
			return this._viewId;
		}

		this.newViewId = function(){
			this._viewId ++;
			return this._viewId;
		}

		this._getPlayer = function(playerId){
			var player = null;
			for (var i=0 ; i<this.playersArray.length ; i++) {
				if(this.playersArray[i].playerId == playerId) player = this.playersArray[i];
			}
			if(player == null){
				player = new gSmPlayer(playerId);
				this.playersArray.push(player);
			}
			return player;
		}

		this._timeCheck = function(){
			setTimeout("gemiusStream._timeCheck()", 1000);
			if (gSmUtil.getTimeSec() - gemiusStream._lastTimeCheck >= gSmConfig.TIMEOUT) {
				gemiusStream._lastTimeCheck = gSmUtil.getTimeSec();
				gSmDebug.send(gSmDebug.DEBUGLEVEL_LOG, "", "", gSmDebug.ACTIONNAME_LOG, ["timeCheck"]);
				this._sendAllStreams();
			}
		}

		this._sendAllStreams = function(){
			for (var i=0 ; i<this.playersArray.length ; i++) {
				this.playersArray[i].sendAllStreams("time");
			}
		}
	}
	gemiusStream.init();
}

(function(d,t) {var ex; try {var gt=d.createElement(t),s=d.getElementsByTagName(t)[0],l='http'+((location.protocol=='https:')?'s':'');
gt.async='true'; gt.defer='true'; gt.src=l+'://sua.hit.gemius.pl/gemiuslib.js'; s.parentNode.insertBefore(gt,s);} catch (ex) {}}(document,'script'));
